import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ParkingSystem {
    private final List<ParkingSpace> spaces;
    private final int levels;
    private final int spacesPerLevel;

    public ParkingSystem(int levels, int spacesPerLevel) {
        this.levels = levels;
        this.spacesPerLevel = spacesPerLevel;
        this.spaces = new ArrayList<>();
        initializeSpaces();
    }

    private void initializeSpaces() {
        for (int level = 0; level < levels; level++) {
            for (int spaceNum = 0; spaceNum < spacesPerLevel; spaceNum++) {
                spaces.add(new ParkingSpace(level, spaceNum));
            }
        }
    }

    public List<ParkingSpace> getAllSpaces() {
        return spaces;
    }

    public ParkingSpace getSpace(int level, int spaceNumber) {
        return spaces.stream()
                .filter(space -> space.getLevel() == level && space.getSpaceNumber() == spaceNumber)
                .findFirst()
                .orElse(null);
    }

    public void loadSavedParkingData() {
        List<FileHandler.VehicleRecord> records = FileHandler.getAllRecords();
        for (FileHandler.VehicleRecord record : records) {
            if ("PARKED".equals(record.getStatus())) {
                ParkingSpace space = getSpace(record.getLevel(), record.getSpace());
                if (space != null) {
                    space.setOccupied(true);
                    space.setParkingStartTime(record.getEntryTime());
                }
            }
        }
    }

    // Inner class ParkingSpace
    public static class ParkingSpace {
        private final int level;
        private final int spaceNumber;
        private boolean isOccupied;
        private LocalDateTime parkingStartTime;  // Changed from long to LocalDateTime

        public ParkingSpace(int level, int spaceNumber) {
            this.level = level;
            this.spaceNumber = spaceNumber;
            this.isOccupied = false;
            this.parkingStartTime = null;
        }

        public int getLevel() {
            return level;
        }

        public int getSpaceNumber() {
            return spaceNumber;
        }

        public boolean isOccupied() {
            return isOccupied;
        }

        public LocalDateTime getParkingStartTime() {
            return parkingStartTime;
        }

        public void occupySpace() {
            this.isOccupied = true;
            this.parkingStartTime = LocalDateTime.now();
        }

        public long vacateSpace() {
            long duration = 0;
            if (parkingStartTime != null) {
                duration = java.time.Duration.between(parkingStartTime, LocalDateTime.now()).toMillis();
            }
            this.isOccupied = false;
            this.parkingStartTime = null;
            return duration;
        }

        public void setOccupied(boolean occupied) {
            this.isOccupied = occupied;
        }

        public void setParkingStartTime(LocalDateTime time) {
            this.parkingStartTime = time;
        }
    }
}