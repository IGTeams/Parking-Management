import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javafx.scene.control.Alert;

public class ParkingManager {
    private final ParkingSystem parkingSystem;
    private static final int MAX_LEVEL = 2;
    private static final int MAX_SPACE = 4;
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final String FILE_PATH = System.getProperty("user.dir") + "/parking_records.txt";

    public ParkingManager(ParkingSystem parkingSystem) {
        this.parkingSystem = parkingSystem;
    }

    public boolean parkVehicle(int level, int spaceNumber, FileHandler.Vehicle  vehicle) {
        validateSpaceLocation(level, spaceNumber);
        
        ParkingSystem.ParkingSpace space = parkingSystem.getSpace(level, spaceNumber);
        if (space != null && !space.isOccupied()) {
            space.occupySpace();
            // Save vehicle entry to file
            FileHandler.saveVehicleEntry(
                vehicle.getVehicleType(),
                level,
                spaceNumber,
                space.getParkingStartTime()
            );
            return true;
        }
        return false;
    }

    public long checkOutVehicle(int level, int spaceNumber) {
        validateSpaceLocation(level, spaceNumber);
        
        ParkingSystem.ParkingSpace space = parkingSystem.getSpace(level, spaceNumber);
        if (space != null && space.isOccupied()) {
            long duration = space.vacateSpace();
            // Update vehicle exit in file
            FileHandler.updateVehicleExit(level, spaceNumber);
            return duration;
        }
        return -1;
    }

    private void validateSpaceLocation(int level, int spaceNumber) {
        if (level < 0 || level > MAX_LEVEL || spaceNumber < 0 || spaceNumber > MAX_SPACE) {
            throw new IllegalArgumentException(
                String.format("Invalid space! Please enter Level (0-%d) and Space (0-%d).", 
                MAX_LEVEL, MAX_SPACE)
            );
        }
    }

    public void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setContentText(message);
        alert.show();
    }

    // Additional utility methods can be added here as needed
    public ParkingSystem getParkingSystem() {
        return parkingSystem;
    }

    // Add method to reload parking data
    public void reloadParkingData() {
        parkingSystem.loadSavedParkingData();
    }

    public static void updateVehicleExit(int level, int space) {
        try {
            List<String> records = new ArrayList<>();
            boolean found = false;

            // Read existing records
            try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("\\|");
                    if (parts.length >= 5) {
                        int recordLevel = Integer.parseInt(parts[1]);
                        int recordSpace = Integer.parseInt(parts[2]);
                        if (recordLevel == level && recordSpace == space && "PARKED".equals(parts[4])) {
                            // Update the status and add exit time
                            line = String.format("%s|%s|%s|%s|%s|%s",
                                    parts[0], parts[1], parts[2], parts[3],
                                    "EXITED", LocalDateTime.now().format(formatter));
                            found = true;
                        }
                    }
                    records.add(line);
                }
            }

            if (found) {
                // Write back all records
                try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_PATH))) {
                    for (String record : records) {
                        writer.println(record);
                    }
                }
            }

        } catch (IOException e) {
            System.err.println("Error updating vehicle exit: " + e.getMessage());
        }
    }

    public static void saveVehicleEntry(String vehicleType, int level, int space, LocalDateTime entryTime) {
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                System.err.println("Could not create file: " + e.getMessage());
                return;
            }
        }
        
        try (FileWriter fw = new FileWriter(FILE_PATH, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw)) {
            
            String record = String.format("%s|%d|%d|%s|%s",
                    vehicleType, level, space, entryTime.format(formatter), "PARKED");
            out.println(record);
            
        } catch (IOException e) {
            System.err.println("Error saving vehicle entry: " + e.getMessage());
        }

    }
}