import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ParkingUIHandler {
    private final ParkingManager manager;
    private final ParkingSystem parkingSystem;
    private static final String[] VEHICLE_TYPES = {"Car", "Motorbike"};
    private static final String IMAGE_PATH = "/Users/bjit/Documents/java_project/src/background.jpeg";

    public ParkingUIHandler(ParkingManager manager, ParkingSystem parkingSystem) {
        this.manager = manager;
        this.parkingSystem = parkingSystem;
    }

    public Scene createMainScene() {
        VBox root = createMainLayout();
        return new Scene(root, 670, 500);
    }

    private VBox createMainLayout() {
        VBox root = new VBox(20);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Text welcomeText = createWelcomeText();
        ImageView parkingImage = loadParkingImage();
        HBox buttonLayout = createMainButtons();

        root.getChildren().addAll(welcomeText, parkingImage, buttonLayout);
        return root;
    }

    private Text createWelcomeText() {
        Text welcomeText = new Text("Welcome to Our Parking Area");
        welcomeText.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        return welcomeText;
    }

    private ImageView loadParkingImage() {
        try {
            Image image = new Image(new FileInputStream(IMAGE_PATH));
            ImageView parkingImage = new ImageView(image);
            parkingImage.setFitWidth(400);
            parkingImage.setPreserveRatio(true);
            return parkingImage;
        } catch (FileNotFoundException e) {
            System.out.println("Image not found: " + e.getMessage());
            return null;
        }
    }

    private HBox createMainButtons() {
        Button[] buttons = {
            createButton("Display Available Space", this::displaySpaces),
            createButton("Park Your Vehicle", this::showParkingDialog),
            createButton("Check Out Your Vehicle", this::showCheckoutDialog),
            createButton("Calculate Parking Fees", this::showFeeCalculationDialog)
        };

        HBox buttonLayout = new HBox(15);
        buttonLayout.setAlignment(Pos.CENTER);
        buttonLayout.getChildren().addAll(buttons);
        return buttonLayout;
    }

    private Button createButton(String text, Runnable action) {
        Button button = new Button(text);
        button.setOnAction(e -> action.run());
        return button;
    }

    private void displaySpaces() {
        Stage stage = new Stage();
        GridPane grid = createSpaceGrid();
        
        Scene scene = new Scene(grid, 300, 200);
        stage.setScene(scene);
        stage.setTitle("Available Spaces");
        stage.show();
    }

    private GridPane createSpaceGrid() {
        GridPane grid = new GridPane();
        grid.setPadding(new Insets(10));
        grid.setHgap(10);
        grid.setVgap(10);

        for (ParkingSystem.ParkingSpace space : parkingSystem.getAllSpaces()) {
            Button spaceButton = new Button(space.getLevel() + "-" + space.getSpaceNumber());
            spaceButton.setBackground(new Background(new BackgroundFill(
                space.isOccupied() ? Color.RED : Color.GREEN, null, null
            )));
            grid.add(spaceButton, space.getSpaceNumber(), space.getLevel());
        }

        return grid;
    }

    private void showParkingDialog() {
        Stage stage = new Stage();
        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        ComboBox<String> typeComboBox = createVehicleTypeComboBox();
        TextField levelField = new TextField();
        TextField spaceField = new TextField();
        Button parkButton = new Button("Park");

        parkButton.setOnAction(e -> handleParking(typeComboBox, levelField, spaceField, stage));

        root.getChildren().addAll(
            new Label("Select Vehicle Type:"), typeComboBox,
            new Label("Enter Level (0-2):"), levelField,
            new Label("Enter Space Number (0-4):"), spaceField,
            parkButton
        );

        stage.setScene(new Scene(root, 300, 300));
        stage.setTitle("Park Vehicle");
        stage.show();
    }

    private void showCheckoutDialog() {
        Stage stage = new Stage();
        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        TextField levelField = new TextField();
        TextField spaceField = new TextField();
        Button checkoutButton = new Button("Check Out");

        checkoutButton.setOnAction(e -> handleCheckout(levelField, spaceField, stage));

        root.getChildren().addAll(
            new Label("Enter Level (0-2):"), levelField,
            new Label("Enter Space Number (0-4):"), spaceField,
            checkoutButton
        );

        stage.setScene(new Scene(root, 300, 200));
        stage.setTitle("Check Out Vehicle");
        stage.show();
    }

    private void showFeeCalculationDialog() {
        Stage stage = new Stage();
        VBox root = new VBox(10);
        root.setPadding(new Insets(10));

        ComboBox<String> typeComboBox = createVehicleTypeComboBox();
        TextField durationField = new TextField();
        Button calculateButton = new Button("Calculate Fees");

        calculateButton.setOnAction(e -> handleFeeCalculation(typeComboBox, durationField, stage));

        root.getChildren().addAll(
            new Label("Select Vehicle Type:"), typeComboBox,
            new Label("Enter Duration (in hours):"), durationField,
            calculateButton
        );

        stage.setScene(new Scene(root, 300, 200));
        stage.setTitle("Calculate Parking Fees");
        stage.show();
    }

    private ComboBox<String> createVehicleTypeComboBox() {
        ComboBox<String> typeComboBox = new ComboBox<>();
        typeComboBox.getItems().addAll(VEHICLE_TYPES);
        typeComboBox.setPromptText("Select Type");
        return typeComboBox;
    }

    private void handleParking(ComboBox<String> typeComboBox, TextField levelField, 
                             TextField spaceField, Stage stage) {
        try {
            validateInputs(levelField, spaceField, typeComboBox);
            int level = Integer.parseInt(levelField.getText().trim());
            int space = Integer.parseInt(spaceField.getText().trim());
            String type = typeComboBox.getValue();

            // Vehicle vehicle = new Vehicle(type);
            FileHandler.Vehicle vehicle = new FileHandler.Vehicle(type);

            if (manager.parkVehicle(level, space, vehicle)) {
                showSuccess("Your " + type + " has been parked at Level " + 
                          level + ", Space " + space + ".");
                stage.close();
            } else {
                throw new IllegalArgumentException("Space is already occupied!");
            }
        } catch (Exception ex) {
            manager.showError(ex.getMessage());
        }
    }

    private void handleCheckout(TextField levelField, TextField spaceField, Stage stage) {
        try {
            int level = Integer.parseInt(levelField.getText().trim());
            int space = Integer.parseInt(spaceField.getText().trim());
            long duration = manager.checkOutVehicle(level, space);
            
            if (duration == -1) {
                manager.showError("No vehicle in this space!");
            } else {
                double fees = calculateFees(duration);
                showSuccess("Parking Fees: RM " + String.format("%.2f", fees));
                stage.close();
            }
        } catch (Exception ex) {
            manager.showError(ex.getMessage());
        }
    }

    private void handleFeeCalculation(ComboBox<String> typeComboBox, 
                                    TextField durationField, Stage stage) {
        try {
            String type = typeComboBox.getValue();
            double hours = Double.parseDouble(durationField.getText().trim());

            validateFeeCalculationInput(type, hours);

            // Vehicle vehicle = new Vehicle(type);
            FileHandler.Vehicle vehicle = new FileHandler.Vehicle(type);

            double fees = vehicle.calculateFee(hours);
            showSuccess("Parking Fees for " + type + ": RM " + 
                       String.format("%.2f", fees));
            stage.close();
        } catch (Exception ex) {
            manager.showError(ex.getMessage());
        }
    }

    private void validateInputs(TextField levelField, TextField spaceField, 
                              ComboBox<String> typeComboBox) {
        if (levelField.getText().isEmpty() || spaceField.getText().isEmpty()) {
            throw new IllegalArgumentException("Level and Space fields cannot be empty.");
        }
        
        if (typeComboBox.getValue() == null || typeComboBox.getValue().isEmpty()) {
            throw new IllegalArgumentException("Please select a vehicle type.");
        }
    }

    private void validateFeeCalculationInput(String type, double hours) {
        if (type == null || type.isEmpty()) {
            throw new IllegalArgumentException("Please select a vehicle type.");
        }
        if (hours <= 0) {
            throw new IllegalArgumentException("Please enter a valid duration greater than 0.");
        }
    }

    private double calculateFees(long duration) {
        return (duration / (1000.0 * 60 * 60)) * 2; // 2 RM per hour
    }

    private void showSuccess(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setContentText(message);
        alert.show();
    }
}