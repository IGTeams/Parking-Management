import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class FileHandler {
    private static final String FILE_PATH = "parking_records.txt";
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void saveVehicleEntry(String vehicleType, int level, int space, LocalDateTime entryTime) {
        try (FileWriter fw = new FileWriter(FILE_PATH, true);
             BufferedWriter bw = new BufferedWriter(fw);
             PrintWriter out = new PrintWriter(bw)) {
            
            String record = String.format("%s|%d|%d|%s|%s",
                    vehicleType, level, space, entryTime.format(formatter), "PARKED");
            out.println(record);
            
        } catch (IOException e) {
            System.err.println("Error saving vehicle entry: " + e.getMessage());
        }
    }

    public static void updateVehicleExit(int level, int space) {
        try {
            List<String> records = new ArrayList<>();
            boolean found = false;

            // Read existing records
            try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split("\\|");
                    if (parts.length >= 5) {
                        int recordLevel = Integer.parseInt(parts[1]);
                        int recordSpace = Integer.parseInt(parts[2]);
                        if (recordLevel == level && recordSpace == space && "PARKED".equals(parts[4])) {
                            // Update the status and add exit time
                            line = String.format("%s|%s|%s|%s|%s|%s",
                                    parts[0], parts[1], parts[2], parts[3],
                                    "EXITED", LocalDateTime.now().format(formatter));
                            found = true;
                        }
                    }
                    records.add(line);
                }
            }

            if (found) {
                // Write back all records
                try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_PATH))) {
                    for (String record : records) {
                        writer.println(record);
                    }
                }
            }

        } catch (IOException e) {
            System.err.println("Error updating vehicle exit: " + e.getMessage());
        }
    }

    public static List<VehicleRecord> getAllRecords() {
        List<VehicleRecord> records = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 5) {
                    VehicleRecord record = new VehicleRecord(
                        parts[0],
                        Integer.parseInt(parts[1]),
                        Integer.parseInt(parts[2]),
                        LocalDateTime.parse(parts[3], formatter),
                        parts[4],
                        parts.length > 5 ? LocalDateTime.parse(parts[5], formatter) : null
                    );
                    records.add(record);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading records: " + e.getMessage());
        }
        return records;
    }

    public static class VehicleRecord {
        private final String vehicleType;
        private final int level;
        private final int space;
        private final LocalDateTime entryTime;
        private final String status;
        private final LocalDateTime exitTime;

        public VehicleRecord(String vehicleType, int level, int space, 
                           LocalDateTime entryTime, String status, LocalDateTime exitTime) {
            this.vehicleType = vehicleType;
            this.level = level;
            this.space = space;
            this.entryTime = entryTime;
            this.status = status;
            this.exitTime = exitTime;
        }

        // Getters
        public String getVehicleType() { return vehicleType; }
        public int getLevel() { return level; }
        public int getSpace() { return space; }
        public LocalDateTime getEntryTime() { return entryTime; }
        public String getStatus() { return status; }
        public LocalDateTime getExitTime() { return exitTime; }
    }

    // Vehicle class integrated into FileHandler
    public static class Vehicle {
        private String vehicleType;
        private static final double CAR_RATE = 2.0;      // 2 RM per hour for cars
        private static final double MOTORBIKE_RATE = 1.0; // 1 RM per hour for motorbikes

        public Vehicle(String vehicleType) {
            this.vehicleType = vehicleType;
        }

        public String getVehicleType() {
            return vehicleType;
        }

        /**
         * Calculates parking fees based on the type of vehicle.
         *
         * @param hours the number of hours the vehicle is parked
         * @return the calculated parking fees
         */
        public double calculateFee(double hours) {
            return switch (vehicleType.toLowerCase()) {
                case "motorbike" -> hours * MOTORBIKE_RATE;
                case "car" -> hours * CAR_RATE;
                default -> 0.0; // Default case (for unknown types)
            };
        }
    }
}