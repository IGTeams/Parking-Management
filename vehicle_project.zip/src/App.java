import javafx.application.Application;
import javafx.stage.Stage;

/**
 * Main application class for the Car Parking Management System.
 * This class initializes the core components and launches the JavaFX application.
 */
public class App extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        try {
            ParkingSystem parkingSystem = new ParkingSystem(3, 5);
            
            // Load saved parking data
            parkingSystem.loadSavedParkingData();
            
            ParkingManager manager = new ParkingManager(parkingSystem);
            ParkingUIHandler uiHandler = new ParkingUIHandler(manager, parkingSystem);
            
            primaryStage.setTitle("Car Parking Management System");
            primaryStage.setScene(uiHandler.createMainScene());
            primaryStage.setResizable(false);
            primaryStage.show();
            
        } catch (Exception e) {
            System.err.println("Error starting application: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Main method to launch the JavaFX application.
     * @param args command line arguments (not used)
     */
    public static void main(String[] args) {
        launch(args);
    }
}